export type SortOption =
  | "moveDateAsc"
  | "moveDateDesc"
  | "createdAtAsc"
  | "createdAtDesc";
