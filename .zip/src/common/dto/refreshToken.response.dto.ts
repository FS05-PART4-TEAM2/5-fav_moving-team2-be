export class RefreshTokenResponseDto {
  accessToken: string;
  refreshToken: string;
}
