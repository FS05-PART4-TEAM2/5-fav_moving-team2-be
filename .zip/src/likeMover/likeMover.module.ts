import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { LikeMover } from "./likeMover.entity";
import { Mover } from "src/mover/mover.entity";
import { likeMoverService } from "./likeMover.service";
import { LikeMoverController } from "./likeMover.controller";
import { AuthModule } from "src/auth/auth.module";

@Module({
  imports: [
    TypeOrmModule.forFeature([LikeMover, Mover]),
    AuthModule, // ✅ 반드시 imports 해줘야 의존성 주입 가능
  ],
  providers: [likeMoverService],
  controllers: [LikeMoverController],
  exports: [TypeOrmModule],
})
export class LikeModule {}
